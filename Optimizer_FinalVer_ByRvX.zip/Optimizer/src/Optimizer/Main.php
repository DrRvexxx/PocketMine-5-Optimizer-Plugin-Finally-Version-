<?php

declare(strict_types=1);

namespace Optimizer;

use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\entity\object\ItemEntity;
use pocketmine\entity\object\ExperienceOrb;
use pocketmine\entity\projectile\Projectile;
use pocketmine\entity\Living;
use pocketmine\entity\Human;
use pocketmine\player\Player;
use Optimizer\Tasks\ClearEntitiesTask;
use Optimizer\Commands\ClearLagCommand;

class Main extends PluginBase {

    private ClearEntitiesTask $task;

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        
        $this->getServer()->getCommandMap()->register("optimizer", new ClearLagCommand($this));
        
        $this->task = new ClearEntitiesTask($this);
        $this->getScheduler()->scheduleRepeatingTask($this->task, 20);
        
        $this->getLogger()->info("§bOptimizer Enabled - By Rvexxx Khanoom =D");
    }

    protected function onDisable(): void {
        $this->getLogger()->info("§cPlugin Disabled");
    }

    public function getTask(): ClearEntitiesTask {
        return $this->task;
    }

    public function clearEntities(): int {
        $count = 0;
        $config = $this->getConfig();
        
        $clearItems = (bool) $config->get("clear_items", true);
        $clearMobs = (bool) $config->get("clear_mobs", false);
        $clearProjectiles = (bool) $config->get("clear_projectiles", true);

        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof Player) {
                    continue;
                }
                
                if ($entity instanceof Human) {
                    continue;
                }
                
                if ($entity->getNameTag() !== "") {
                    continue;
                }

                $className = strtolower((new \ReflectionClass($entity))->getShortName());
                if (str_contains($className, "npc") || str_contains($className, "slapper") || str_contains($className, "citizen")) {
                    continue;
                }

                if ($entity->getScale() !== 1.0) {
                    continue;
                }
                
                $shouldClear = false;
                
                if ($clearItems && ($entity instanceof ItemEntity || $entity instanceof ExperienceOrb)) {
                    $shouldClear = true;
                } elseif ($clearProjectiles && $entity instanceof Projectile) {
                    $shouldClear = true;
                } elseif ($clearMobs && $entity instanceof Living) {
                    $shouldClear = true;
                }
                
                if ($shouldClear) {
                    $entity->flagForDespawn();
                    $count++;
                }
            }
        }
        
        return $count;
    }
}