<?php

declare(strict_types=1);

namespace Optimizer\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginOwned;
use pocketmine\Server;
use Optimizer\Main;

class ClearLagCommand extends Command implements PluginOwned {

    private Main $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("clearlag", "Manually clear entities", "/clearlag", ["cl"]);
        $this->setPermission("optimizer.command");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) {
            return true;
        }
        
        $count = $this->plugin->clearEntities();
        $this->plugin->getTask()->resetTimer();
        
        Server::getInstance()->broadcastMessage("§l§e[ClearLag] §r§aAdmin manually cleared §2{$count} §aentities.");
        return true;
    }

    public function getOwningPlugin(): Main {
        return $this->plugin;
    }
}