<?php

declare(strict_types=1);

namespace Optimizer\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use Optimizer\Main;

class ClearEntitiesTask extends Task {

    private Main $plugin;
    private int $runTime = 0;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        $interval = (int) $this->plugin->getConfig()->get("clear_interval", 300);
        $warningTime = (int) $this->plugin->getConfig()->get("warning_seconds", 10);
        
        $this->runTime++;

        if ($this->runTime === ($interval - $warningTime)) {
            Server::getInstance()->broadcastMessage("§l§e[ClearLag] §r§cWarning: Entities will be cleared in {$warningTime} seconds!");
        }

        if ($this->runTime >= $interval) {
            $count = $this->plugin->clearEntities();
            Server::getInstance()->broadcastMessage("§l§e[ClearLag] §r§aSuccessfully cleared §2{$count} §aentities.");
            $this->runTime = 0;
        }
    }

    public function resetTimer(): void {
        $this->runTime = 0;
    }
}